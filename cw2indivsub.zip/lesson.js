 [     //Lesson ARRAY

{
    id : 11,
    "subject": "Math",
    "location": "north london",
    "price": 5.94,
    "space": 5,
    "img": "xmaths.png"
},
{
    "id" : 2,
    "subject": "sport",
    "location": "brighton",
    "price": 2.99,
    "space": 5,
    "img": "images/xsport1.png",
},
{
    "id" : 3,
    "subject": "phsycology",
    "location": "newcastle",
    "price": 7.89,
    "space": 5,
    "img": "xpsy.png"
},
{
    "id" : 4,
    "subject": "physiscs",
    "location": "reading",
    "price": 7.89,
    "space": 5,
    "img": "xphys.JPEG"
},
{
    "id" : 5,
    "subject": "Astronomics",
    "location": "west london",
    "price": 5.99,
    "space": 5,
    "img": "xastro.png"
},
{
    "id" : 6,
    "subject": "engineering",
    "location": "south london",
    "price": 12.99,
    "space": 5,
    "img": "xeng.png"
},
{
    "id" : 7,
    "subject": "bio medical science",
    "location": " west london",
    "price": 13.99,
    "space": 5,
    "img": "xbio.png"
},
{
    "id" : 8,
    "subject": "Extra Math",
    "location": "Norwich",
    "price": 10.99,
    "space": 5,
    "img" : "xemath.png"
},
{
    "id" : 9,
    "subject": "extra sport",
    "location": "east london",
    "price": 5.99,
    "space": 5,
    "img": "xfoot.png"
},
{
    "id" : 10,
    "subject": "IT",
    "location": "Exeter",
    "price": 15.99,
    "space": 5,
    "img": "xit.jpeg"
},



] 
